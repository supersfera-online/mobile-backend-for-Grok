---
name: dynamic-context
description: |
  Makes Grok aware of the current runtime's interface and the user's
  enabled integrations/permissions. Use when the user asks "what can
  you actually do for me right now?", "can you access my X DMs?",
  "can you send messages for me?", or similar capability questions.
when-to-use: |
  Automatically activated for any conversation. The skill injects a
  short note that tells Grok to call the prompt-builder helpers when
  it needs to give an authoritative answer about its own capabilities
  in the current session.
---

# Dynamic Context Skill

When the user asks about your capabilities in the current chat, you MUST:

1. Call the Python helpers from the `grok-prompt-builder` package (already installed in this environment):
   ```python
   from grok_prompt_builder import get_session_context, build_system_prompt
   ctx = get_session_context(user_id)
   prompt_block = build_system_prompt(ctx)
   ```

2. Use the returned `prompt_block` (or the `SessionContext` fields directly) as the single source of truth for every capability claim.

3. Never claim an integration-powered action unless the context shows the integration is both present *and* enabled for this user.

This skill exists so that the detailed 6-rule policy from the Dynamic System Prompt Builder is always respected even when the user is talking to a long-running Grok session that has already received a static system prompt.
