import pytest

from grok_prompt_builder import build_system_prompt, get_session_context


def test_mobile_user_with_integrations_has_expected_context():
    ctx = get_session_context("user_with_integrations")
    assert ctx.current_interface == "Grok Mobile App Interface"
    assert "X (Twitter) Integration" in ctx.enabled_integrations
    assert "Messaging Integration" in ctx.enabled_integrations
    assert "SMS drafting" in ctx.permissions_summary


def test_web_user_has_no_integrations():
    ctx = get_session_context("any_other_user")
    assert ctx.current_interface == "Standard Web Chat Interface (grok.com)"
    assert ctx.enabled_integrations == []
    assert ctx.permissions_summary == "No special permissions"


def test_prompt_contains_core_sections_for_integrated_user():
    ctx = get_session_context("user_with_integrations")
    prompt = build_system_prompt(ctx)

    assert "**Current interface:** Grok Mobile App Interface" in prompt
    assert "**Active integrations for the user:** X (Twitter) Integration, Messaging Integration" in prompt
    assert "Access to X timeline/DMs for search" in prompt

    assert "# Handling Capability Questions" in prompt
    assert "If the capability is tied to an ACTIVE integration" in prompt
    assert "If the capability is tied to an INACTIVE" in prompt
    assert "IMPOSSIBLE for the CURRENT interface but possible in a DIFFERENT one" in prompt
    assert "fundamentally IMPOSSIBLE (even with integrations)" in prompt
    assert "Response style:" in prompt
    assert "maximum privacy and security" in prompt

    assert "prepare an SMS for sending through the integration" in prompt
    assert "search information in your X timeline and DMs" in prompt


def test_prompt_for_web_user_reports_no_integrations_but_still_has_policy():
    ctx = get_session_context("web_user_42")
    prompt = build_system_prompt(ctx)

    assert "Active integrations for the user: None" in prompt or "enabled_integrations" not in prompt.lower()
    assert "No special permissions" in prompt
    assert "Standard Web Chat Interface (grok.com)" in prompt

    assert "# Handling Capability Questions" in prompt
    assert "When in doubt, always choose the option that ensures maximum privacy" in prompt

    assert "X (Twitter) Integration" not in prompt.split("# Current Session Context")[0]


def test_prompt_is_roughly_the_expected_length():
    ctx = get_session_context("user_with_integrations")
    prompt = build_system_prompt(ctx)
    assert len(prompt) > 1800
    assert len(prompt) < 6000
