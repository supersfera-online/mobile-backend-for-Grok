from __future__ import annotations

import datetime
from dataclasses import dataclass, field
from typing import List, Optional


@dataclass(frozen=True)
class SessionContext:
    model_version: str = "Grok 4 (Simulated Runtime)"
    provider_name: str = "xAI"
    current_interface: str = "Standard Web Chat Interface (grok.com)"
    user_language: str = "English"
    user_location: Optional[str] = None
    enabled_integrations: List[str] = field(default_factory=list)
    permissions_summary: str = "No special permissions"
    session_start_time: str = field(default_factory=lambda: datetime.datetime.now().isoformat())
    user_id: str = "unknown"


_DEMO_PROFILES = {
    "user_with_integrations": SessionContext(
        current_interface="Grok Mobile App Interface",
        user_location="San Francisco",
        enabled_integrations=["X (Twitter) Integration", "Messaging Integration"],
        permissions_summary="Access to X timeline/DMs for search; Access to Contacts and SMS drafting",
        user_id="user_with_integrations",
    ),
}


def get_session_context(user_id: str) -> SessionContext:
    print(f"[INFO] Fetching context for user_id: {user_id}...")

    if user_id in _DEMO_PROFILES:
        ctx = _DEMO_PROFILES[user_id]
    else:
        ctx = SessionContext(user_id=user_id)

    import json

    print(
        f"[INFO] Context retrieved: {json.dumps(ctx.__dict__, indent=2, ensure_ascii=False)}"
    )
    return ctx
