from __future__ import annotations

from .context import get_session_context
from .prompt import build_system_prompt


def main() -> None:
    print("--- Starting Hypothetical AI Model Initialization Script (Generalized) ---")

    current_user_id = "user_with_integrations"
    session_context = get_session_context(current_user_id)
    dynamic_system_prompt = build_system_prompt(session_context)

    print("\n--- Dynamic System Prompt Generated ---")
    print(
        f"(Prompt generated for user {session_context.user_id} using model "
        f"{session_context.model_version} from {session_context.provider_name} "
        f"in interface '{session_context.current_interface}' with integrations: "
        f"{session_context.enabled_integrations})"
    )
    print("--------------------------------------")

    preview = dynamic_system_prompt[:800].replace("\n", " ")[:300]
    print(f"\n[INFO] Prompt preview (first ~300 chars): {preview}...")

    print("\n[INFO] Initializing model or making first API call with the generated system prompt...")
    print("[INFO] Conceptual initialization complete. Model is ready with context-aware instructions.")

    print("\n--- Script Finished ---")


if __name__ == "__main__":
    main()
