# Dynamic System Prompt Builder — Integration Guide

This document describes how platform clients should prepare and upload context for Grok so that it can accurately and safely answer capability questions.

## The Problem
Static system prompts cannot know which interface the user is in or which integrations they have enabled. This leads to the model either over-claiming or under-claiming its abilities.

## Solution
Prepare a clean folder with this structure and upload it via GitHub web interface (drag & drop).

Recommended folder structure for easy web upload:

grok-prompt-builder/
├── grok_prompt_builder/
├── docs/
├── tests/
├── LICENSE
├── NOTICE
├── README.md
├── pyproject.toml
└── verify_prompt_builder.py

No hidden folders are needed for basic web upload.

## Upload Instructions (Web Interface)
1. Go to your GitHub repository.
2. Click "Add file" → "Upload files".
3. Drag the entire `grok-prompt-builder` folder (or its contents) into the upload area.
4. Commit the changes.

This is the simplest way for one or few upload actions.
